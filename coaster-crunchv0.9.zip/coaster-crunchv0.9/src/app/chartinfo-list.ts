import { Chartinfo } from './chartinfo-class';


export const CHARTINFOS: Chartinfo[] = [
    
    //Height info-------------------------------------------------------------------------------------------------------
    {
        id: "heightOne",
        type: "pie",
        labels: ["0-90 ft.", "91-180 ft.","181-270 ft.", "271-360 ft.", "361-450 ft."],
        data: [],
        color_scheme: ['#4D4D4D','#F17CB0','#60BD68','#FAA43A','#581845'],
    },

    {
        id: "heightTwo",
        type: "pie",
        labels: ["wood","steel"],
        data: [],
        color_scheme: ['#B2912F','#4D4D4D',]
    },

    {
        id: "heightThree",
        type: "pie",
        labels: ["australia", "north america", "south america", "europe", "asia", "africa", "antartica"],
        data: [],
        color_scheme: ['#4D4D4D','#F17CB0','#60BD68','#FAA43A',  '#581845','#B276B2','#DECF3F']
    },

    {
        id: "heightOne",
        type: "pie",
        labels: ["0-90 ft.", "91-180 ft.","181-270 ft.", "271-360 ft.", "361-450 ft."],
        data: [],
        color_scheme: ['#4D4D4D','#F17CB0','#60BD68','#FAA43A','#581845'],
   
    },

    //Length info-------------------------------------------------------------------------------------------------------------

    {
        id: "lengthtOne",
        type: "pie",
        labels: ["0-1000 ft.", "1001-2000 ft.", "2001-3000 ft.", "3001-4000 ft.", "4001-5000 ft.", "5001-6000 ft.", "6001-7000 ft.","7001-8000 ft."],
        data: [],
        color_scheme: ['#4D4D4D','#F17CB0','#60BD68','#FAA43A','#581845','#B276B2','#DECF3F','#99CC88']
    },

    {
        id: "lengthTwo",
        type: "pie",
        labels: ["wood","steel"],
        data: [],
        color_scheme: ['#B2912F','#4D4D4D']
        
    },

    {
        id: "lengthThree",
        type: "pie",
        labels: ["australia", "north america", "south america", "europe", "asia", "africa", "antartica"],
        data: [],
        color_scheme: ['#4D4D4D','#F17CB0','#60BD68','#FAA43A',  '#581845','#B276B2','#DECF3F']
    },

    {
        id: "lengthtOne",
        type: "pie",
        labels: ["0-90 ft.", "91-180 ft.","181-270 ft.", "271-360 ft.", "361-450 ft."],
        data: [],
        color_scheme: ['#4D4D4D','#F17CB0','#60BD68','#FAA43A','#581845','#B276B2','#DECF3F','#99CC88']
    },

    //Speed info---------------------------------------------------------------------------------------------------------------------

    {
        id: "speedOne",
        type: "pie",
        labels: ["0-20 mph.", "21-40 mph.", "41-60 mph.", "61-80 mph.", "81-100 mph.", "101-120 mph.", "121-140 mph."],
        data: [],
        color_scheme: ['#4D4D4D','#F17CB0','#60BD68','#FAA43A','#581845','#B276B2','#DECF3F']
    
    },

    {
        id: "speedTwo",
        type: "pie",
        labels: ["wood","steel"],
        data: [],
        color_scheme: ['#B2912F','#4D4D4D']
    },

    {
        id: "speedThree",
        type: "pie",
        labels: ["australia", "north america", "south america", "europe", "asia", "africa", "antartica"],
        data: [],
        color_scheme: ['#4D4D4D','#F17CB0','#60BD68','#FAA43A',  '#581845','#B276B2','#DECF3F']
    },

    {
        id: "speedOne",
        type: "pie",
        labels: ["0-90 ft.", "91-180 ft.","181-270 ft.", "271-360 ft.", "361-450 ft."],
        data: [],
        color_scheme: ['#4D4D4D','#F17CB0','#60BD68','#FAA43A','#581845','#B276B2','#DECF3F']
    
    },

    //Bar Graph---------------------------------------------------------------------------------------------------------
    {
        id:"barGraph",
        type: "bar",
        labels: ["australia","north america","south america","europe","asia","africa","antartica"],
        data: [0,0,0,0,0,0],
        color_scheme: ['#1f77b4','#ff7f0e','#2ca02c','#17becf','#7f7f7f','#FAA43A','#581845'],
    },


]