import { Injectable } from '@angular/core';
import { Chartinfo } from './chartinfo-class';
import { CHARTINFOS } from './chartinfo-list';
import { Coaster } from './coaster-class';
import { COASTERS } from './coaster-list';


@Injectable()
export class CoasterService {

  constructor() { }

  chartinfo = Chartinfo;
  
  chartinfos = CHARTINFOS;

  info;

  targetlist;

  ascending = 1;

  //To trigger length it has to be 1, ot trigger height it has to be 2, and to triggler speed it has to be 3.
  datafocus = 1;

  speedRange = [0,20,40,60,80,100,120,140];

  lengthRange = [0,1000,2000,3000,4000,5000,6000,7000,8000];

  heightRange = [0,90,180,270,360,480];

  woodOrSteel = ["wood","steel"];

  continents = ["australia","north america","south america","europe","asia","africa","antartica"];

  pieData = [];

  arr = [];

//---------------------------------Table Related Functions----------------------------------------------
  
//This places all of the coasters and their value pairs into a 2d array that can be manipulated later.  
  initializeArray()
  {
    for (var i = 0; i < COASTERS.length; i += 1)
    {

      this.arr[i] = [];

        for (var j = 0; j <= 6; j += 1)
        {
          switch (j) {
            case 0:this.arr[i][j] = COASTERS[i].name; break;
            case 1:this.arr[i][j] = COASTERS[i].length; break;  
            case 2:this.arr[i][j] = COASTERS[i].height; break;    
            case 3:this.arr[i][j] = COASTERS[i].speed; break;
            case 4:this.arr[i][j] = COASTERS[i].type; break;
            case 5:this.arr[i][j] = COASTERS[i].park; break;  
            case 6:this.arr[i][j] = COASTERS[i].continent; break; 
          }  
        }
    }
  }
  
  //Sets the order of display either to ascending or descending depending on what is passed in.
  setOrder(ascending)
  {
    this.ascending = ascending;
  }

  //Sets the data to be focused on for the sort.
  setDataFocus(datafocus)
  {
    this.datafocus = datafocus;
  }

  //The sorting algorithm that will place things in correct numerical order.
  insertionSort()
  { 
      for (var i = 0; i < this.arr.length; i+=1){
      
          //Assigns the current item to be shifted if the right conditions are met.
          var key = this.arr[i];
  
          //Key 2 assigns the numerical data type to be sorted by.
          var key2 = key[this.datafocus];
  
          var j = i - 1;
  
          //Puts numerical data focus in order from smallest to largest.
          if (this.ascending === 1) 
          {
              while (j >= 0 && this.arr[j][this.datafocus] > key2) // <--- You can flip the "<" to change ascending/descending order
              { 
                  this.arr[j+1] = this.arr[j];
                  j -=1;
              }
          }   
          //Puts numerical data focus in order from largest to smallest.
          else if (this.ascending === -1)
          {
              while (j >= 0 && this.arr[j][this.datafocus] < key2) // <--- You can flip the "<" to change ascending/descending order
              { 
                  this.arr[j+1] = this.arr[j];
                  j -=1;
              }
          }
          //increment the key until all of the keys have been sorted through.
          this.arr[j+1] = key;
      }
  
  }

  //--------------------------------------------Pie Chart Related Functions-------------------------------------


  count()
  {
      //This gets rid of anything that is in the array that will hold the results.
      this.pieData.splice(0,this.pieData.length);
      
      //The switch statement makes sure that the appropriate range list is being evaluated in the loops.
      switch (this.datafocus)
      {
          case 1: this.targetlist= this.lengthRange; this.info = this.chartinfos[0].data; break;
          case 2: this.targetlist= this.heightRange; this.info = this.chartinfos[3].data; break;
          case 3: this.targetlist= this.speedRange; this.info = this.chartinfos[6].data ; break;
      }
                      
      //for i = 0 and i is less than the length of the range array being used, increment i by 1
      for(var i = 0; i < this.targetlist.length-1; i += 1)
      {
          //intializes an empty index to store the total number of coasters in the given range 
          this.pieData.push(0);
          //add it to the index that was initialized above
            
          //this.chartinfos[0].data.push(0);
  
          //for j = o and is less than the total number of coasters in the js file, incement j by 1
          for (var j = 0; j < 508; j += 1)
          {
              //if i is not equal to the last number in the range do the code below. This prevents it from returning undefined
              if (i < this.targetlist.length)
              {
                  //if the current coaster datafocus being assesed is between the two selected ranges
                  if ((this.arr[j][this.datafocus] > this.targetlist[i]) && (this.arr[j][this.datafocus] < this.targetlist[i + 1])) 
                  {
                      //add it to the index that was initialized above
                      this.pieData[i] = this.pieData[i] + 1; 
                  }
              }
              else
              {
                  //if i is equal to the index of the last range
                  if(this.arr[j][this.datafocus] > this.targetlist[i]) 
                  {
                      //add it to the index that was initialized above
                      this.pieData[i] = this.pieData[i] + 1;   
                  }
              }
          }
  
          if (i != this.targetlist.length)
          {
          //console.log(this.pieData[i] + " coasters are between " + this.targetlist[i] + " and " + this.targetlist[i+1]);
          }
      }
      this.addData(1);
  }

  woodVsSteel()
  {
      //This gets rid of anything that is in the array that will hold the results.
      this.pieData.splice(0,this.pieData.length);
  
      //use the data focus to set the targetlist to the appropriate measuremet.
      switch (this.datafocus)
      {
          //These target lists are the ranges.
          case 1: this.targetlist= 400; break;
          case 2: this.targetlist= 50; break;
          case 3: this.targetlist= 30; break;
      }
  
      for(var i = 0; i < 2; i ++ )
      {
          //create an empty index;
          this.pieData.push(0);
  
          for(var j = 0; j < 508; j ++)
          {
              //If the (length,height, or speed) is greater than the targetlist range, and the type of the coaster is equal to wood or steel
              if ((this.arr[j][this.datafocus] > this.targetlist) && (this.arr[j][4] == this.woodOrSteel[i]))
              {
                  //add to the pie data
                  this.pieData[i] = this.pieData[i] + 1;
              }    
          }
          //console.log(pieData[i] + " rollercoasters are made from " + woodOrSteel[i]);
      }
      this.addData(2);
  }

  topContinent()
  {
      //This gets rid of anything that is in the array that will hold the results.
      this.pieData.splice(0,this.pieData.length);
  
      //makes sure that the sorting algorithm puts the largest numbers in the lowest list indexes
      this.ascending = -1;
      
      //chooses which numerifal figue to sort the list by
      //datafocus = 3;
  
      //Call the sorting function
      this.insertionSort();
  
      for(var i = 0; i < this.continents.length; i += 1)
      {
  
          //create an empty index;
          this.pieData.push(0);
          //this.chartinfos[2].data.push(0);
  
          //iterate through the top 50 or whatever datafocus is chosen
          for(var j = 0; j < 200; j += 1)
          {
              if (this.arr[j][6] === this.continents[i])
              {
                  this.pieData[i] = this.pieData[i] + 1;
                  //this.chartinfos[2].data[i] = this.chartinfos[2].data[i] + 1;
              }
          }
        }
    this.addData(3);
  }

  mostCoasters()
  {
      //This gets rid of anything that is in the array that will hold the results.
      //this.pieData.splice(0,this.pieData.length);
  
      for (var i = 0; i < this.continents.length; i += 1)
      {
          //initialize the empty list
          //this.pieData.push(0);
  
              for (var j = 0; j < 508; j += 1)
              {
                  if (this.arr[j][6] === this.continents[i])
                  {
                      //this.pieData[i] = this.pieData[i] + 1;
                      this.chartinfos[12].data[i] = this.chartinfos[12].data[i] +=1;
                  }
              }
              console.log(this.continents[i] + " has " + this.chartinfos[12].data[i] + "coasters");
  
      }
  
  }

  addData(callingMethod)
  {
    
    if (callingMethod == 1)
    {
      for ( var i = 0; i < this.pieData.length; i += 1)
        {
            switch(this.datafocus)
            {
            case 1 : this.chartinfos[4].data[i] = this.pieData[i]; this.chartinfos[7].data[i] = this.pieData[i];break;
            case 2 : this.chartinfos[0].data[i] = this.pieData[i]; this.chartinfos[3].data[i] = this.pieData[i]; break;
            case 3 : this. chartinfos[8].data[i] = this.pieData[i]; this.chartinfos[11].data[i] = this.pieData[i]; break;
            }
        }
    }
    
    if (callingMethod == 2)
        {
          for ( var i = 0; i < this.pieData.length; i += 1)
            {
                switch(this.datafocus)
                {
                case 1 : this.chartinfos[5].data[i] = this.pieData[i]; break;
                case 2 : this.chartinfos[1].data[i] = this.pieData[i]; break;
                case 3 : this. chartinfos[9].data[i] = this.pieData[i]; break;
                }
            }
        }
    if (callingMethod == 3)
        {
            for ( var i = 0; i < this.pieData.length; i += 1)
            {
                switch(this.datafocus)
                {
                case 1 : this.chartinfos[6].data[i] = this.pieData[i]; break;
                case 2 : this.chartinfos[2].data[i] = this.pieData[i]; break;
                case 3 : this. chartinfos[10].data[i] = this.pieData[i]; break;
                }
            }
        }
  }

  //getPieData()
 // {
 //   return this.pieData;
  //}

  getCoasters() {
    return this.arr;
  }
}


