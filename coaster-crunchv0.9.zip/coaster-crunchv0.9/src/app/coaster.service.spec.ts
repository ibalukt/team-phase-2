import { TestBed, inject } from '@angular/core/testing';

import { CoasterService } from './coaster.service';

describe('CoasterService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CoasterService]
    });
  });

  it('should be created', inject([CoasterService], (service: CoasterService) => {
    expect(service).toBeTruthy();
  }));
});
