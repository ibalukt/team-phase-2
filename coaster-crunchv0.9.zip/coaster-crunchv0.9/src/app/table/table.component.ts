import { Component, OnInit } from '@angular/core';
import { Coaster } from '../coaster-class';
//import { COASTERS } from '../coaster-list';
import { CoasterService } from '../coaster.service';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {

  //dependency injection
  constructor(private coasterService: CoasterService) { }

  //coaster is equal to the class Coaster.
  coaster = Coaster;

  //coasters is equal to a list of the coaster objects.
  coasters: Coaster[];

  show = -1;

  ngOnInit() {
    
  }

  getCoasters(): void {
    //coasters is retrieving the coaster list from the coasterService's getCoasters method.
    this.coasterService.insertionSort();
    this.coasters = this.coasterService.getCoasters();
  }

  viewToggle(): void {
    this.show *= -1;
  }

}
