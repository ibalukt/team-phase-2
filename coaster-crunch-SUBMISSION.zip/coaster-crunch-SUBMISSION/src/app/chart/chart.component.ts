import { Component, OnInit, Input, AfterViewInit } from '@angular/core';
import * as Chart from 'chart.js';
import { Chartinfo } from '../chartinfo-class';
import { CHARTINFOS } from '../chartinfo-list';
import { CoasterService } from '../coaster.service';

@Component({
  selector: 'app-chart',
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.css']
})
export class ChartComponent implements OnInit {

 @Input() childMessage;

  constructor(public coasterService: CoasterService) { 
  }

    pieData;
  
    id; 
    
    elemid;
  
    chartinfo = Chartinfo;
    
    chartinfos = CHARTINFOS;
  
    chart: any;



  //This gets the data for the charts. If you call this in the ngAfterViewInit, the data won't be loaded into the chart correctly.
  ngOnInit()
  {
    this.elemid = JSON.stringify(this.childMessage);
    this.id = parseInt(this.childMessage,10)
  }


  ngAfterViewInit() {

        if (this.id == 12)
        {
            this.chart = new Chart(this.elemid, {
            
                // The type of chart we want to create
                type: this.chartinfos[this.id].type,
                // The data for our dataset  
                data: {
                    labels:this.chartinfos[this.id].labels,
                    datasets: [{
                        label: 'Rides Per Continent',
                        data: this.chartinfos[this.id].data,
                        backgroundColor: this.chartinfos[this.id].color_scheme,
                        borderColor: '#140A1E'                  
                    }]
                },
                // Configuration options go here
                options: {
                    legend: {
                        labels: {
            
                            fontColor: 'white'
            
                        }
                    },
                    scales: {       
                        yAxes: [{
                            ticks: {
                                fontColor:'#FFC62F',
                                beginAtZero:true
                            },
                            gridLines: {
                                color:'#140A1E'
            
            
                            }
                          
                        }],
                        xAxes:[{
                            gridLines: {
                                display:false,
                                color:'#140A1E'
            
                            },
                            ticks:{
                                fontColor:'#FFC62F',
                                autoSkip: false
                            },          
                        }]
                    }
                }            
            });
        }

        else
        {
                    this.chart = new Chart(this.elemid, {
                        
                            // The type of chart we want to create
                            type: this.chartinfos[this.id].type,
                            // The data for our dataset  
                            data: {
                                labels:this.chartinfos[this.id].labels,
                                datasets: [{
                                    data: this.chartinfos[this.id].data,
                                    backgroundColor: this.chartinfos[this.id].color_scheme,
                                    borderColor: '#140A1E'                  
                                }]
                            },
                            // Configuration options go here
                            options: {
                                maintainAspectRatio: false,
                                    legend: {
                                        labels: {
                                            fontColor: 'black'
                                        }
                                    },

                 }
            });
        }
    }
        
}

