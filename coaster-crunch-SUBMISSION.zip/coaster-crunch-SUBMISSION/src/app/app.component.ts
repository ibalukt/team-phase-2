import { Component } from '@angular/core';
import { CoasterService } from './coaster.service';
import { HttpModule }      from '@angular/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';

  constructor(private coasterService: CoasterService) { }

  ngOnInit(){
    this.coasterService.initializeArray();
    //this.getCoasters();
    this.coasterService.setDataFocus(2);
    this.coasterService.count();
    this.coasterService.woodVsSteel();
    this.coasterService.topContinent();
    this.coasterService.setDataFocus(1);
    this.coasterService.count();
    this.coasterService.woodVsSteel();
    this.coasterService.topContinent();
    this.coasterService.setDataFocus(3);
    this.coasterService.count();
    this.coasterService.woodVsSteel();
    this.coasterService.topContinent();
    this.coasterService.mostCoasters(); 
  }
}
