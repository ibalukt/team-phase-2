import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-slider',
  templateUrl: './slider.component.html',
  styleUrls: ['./slider.component.css']
})
export class SliderComponent implements OnInit {

  @Input() sliderNumber;

  constructor() { }

  ngOnInit() {
  //This sets what charts end up in what sliders.
    if (this.sliderNumber == 1)
    {
      this.chartNumber = [0,1,2,3];
    }
    else if (this.sliderNumber == 2)
    {
      this.chartNumber = [4,5,6,7];
    }
    else if (this.sliderNumber == 3)
    {
      this.chartNumber = [8,9,10,11];
    }
 }

  chartNumber = [];

  screenWidth = window.innerWidth * .9;

  moveInterval;

  posX = 0;

  target = 500;

  Movetimer = 0;

  RoL = 0;

  index = 0;

  distance = 0;


  //This will be triggered when you resize the window.
  widthCheck()
  {
    this.screenWidth = window.innerWidth * .9;
    this.posX = this.index * this.screenWidth; 

  }


  prepSlider(RoL) {
    // This if statement makes sure that you can not trigger the slider when it is already moving.
    if ((this.distance > -10) && (this.distance < 10))
    {

      //If right is pressed
      if (RoL == -1)
      {
        if (this.index != -3)
        {
        this.index += (1 * RoL);
        //this.target = (this.index * 320);
        }
        else
        {
        this.posX = 0;
        this.index = -1;  
        }
      }

      //If left is pressed
      if (RoL == 1)
      {
        if (this.index != 0)
        {
        this.index += (1 * RoL);
        //this.target = (this.index * 320);
        }
        else
        {
        this.posX = this.screenWidth * -3;
        this.index = -2;  
        }
      } 

      this.target = (this.index * (this.screenWidth))

      //This function triggers the actual moving process for the slider and takes a parameter of target.
      this.move(this.target);
    }
  }

  move(target) {

    //This is the interval that sets what triggers the movement of the slider.
    this.moveInterval = setInterval(() => {

      this.distance = this.posX - this.target;

      //If the x position is less than the target, add to the x position. This causes the sliding box to move right.
      if (this.posX < this.target)
        {
          this.posX = this.posX + 4;
        }
      //If the position is greater than the target, subtract from the x position. this causes the box to move left.  
      if (this.posX > this.target)
        {
          this.posX = this.posX - 4;
        }

      /*This code says that if the distance is in the range from -5 to 5 to automatically set the x position to the target and 
      clear the interval */

      if ((this.distance > -10) && (this.distance < 10)) 
        {
          this.posX = this.target;
          clearInterval(this.moveInterval);
        }
    //This is how fast the slider will actually.
    }, 3);
  }
}
