export class Chartinfo {
    id: string;
    type: string;
    labels: object;
    data: object;
    color_scheme: object;
}