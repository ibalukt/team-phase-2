export class Coaster {

    name: string;
    height: number;
    length: number;
    speed: number;
    type: string;
    park: string;
    continent: string;
}