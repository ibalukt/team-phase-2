import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule }      from '@angular/http';


import { AppComponent } from './app.component';
import { SliderComponent } from './slider/slider.component';
import { TableComponent } from './table/table.component';
import { CoasterService } from './coaster.service';
import { ChartComponent } from './chart/chart.component';


@NgModule({
  declarations: [
    AppComponent,
    SliderComponent,
    TableComponent,
    ChartComponent
  ],
  imports: [
    BrowserModule, HttpModule
  ],
  providers: [CoasterService],
  bootstrap: [AppComponent]
})
export class AppModule { }
